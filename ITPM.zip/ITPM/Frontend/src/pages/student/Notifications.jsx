import React from "react";

function Notifications () {


    return(
        <>
   

            <h1>These are Student Notifications</h1>
      
        
        </>

    )
}
export default Notifications;