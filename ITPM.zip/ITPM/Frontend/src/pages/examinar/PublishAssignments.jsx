import React from "react";

export default function PublishAssignments() {

    return(
        <>
        <h1>Publish Assignments</h1>
        </>
    )
};