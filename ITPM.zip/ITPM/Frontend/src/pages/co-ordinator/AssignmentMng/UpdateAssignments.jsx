import React from 'react'

function UpdateAssignments() {
  return (
    <div>UpdateAssignments</div>
  )
}

export default UpdateAssignments