import React from 'react'
// each student's final marks
function StudentFinalMarks_3() {
  return (
    <div>StudentFinalMarks_3</div>
  )
}

export default StudentFinalMarks_3