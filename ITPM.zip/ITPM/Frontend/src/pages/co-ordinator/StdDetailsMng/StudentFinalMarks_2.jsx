import React from 'react'
//each group marks
function StudentFinalMarks_2() {
  return (
    <div>StudentFinalMarks_2</div>
  )
}

export default StudentFinalMarks_2