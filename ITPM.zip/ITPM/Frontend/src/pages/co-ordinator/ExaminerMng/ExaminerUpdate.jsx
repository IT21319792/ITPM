import React from 'react'

function ExaminerUpdate() {
  return (
    <div>ExaminerUpdate</div>
  )
}

export default ExaminerUpdate