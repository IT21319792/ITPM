import React from 'react'

function ProjectMemberUpdate() {
  return (
    <div>ProjectMemberUpdate</div>
  )
}

export default ProjectMemberUpdate