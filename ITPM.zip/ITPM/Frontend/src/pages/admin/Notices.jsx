import React from "react";

export default function Notices() {


    return(
        <h1>admin notices</h1>
    )
}