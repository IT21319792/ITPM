import React from "react";

import AdminWelcomeCard from "../../components/AdminWelcomeCard";

function AdminDash () {


    return (
        <>
        <AdminWelcomeCard />
        
           
   {/* <AddUsersSuperAdmin/> */}
        

        </>
     
    );
}

export default AdminDash;